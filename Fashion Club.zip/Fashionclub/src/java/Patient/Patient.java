package Patient;



public class Patient {

    private int id;
 
    private String Username;
     private String email;
    private String password;
    private String Phone;
    private String Address;
   

    
//    @Override
////   
//    public String toString() {
//        return "Patient{" + "id=" + id + ", Username=" + Username +", email=" + email + ", password=" + password + ",Phone=" + Phone + ", Address=" + Address +'}';
//    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return Username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.Username = username;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the Phone
     */
    public String getPhone() {
        return Phone;
    }

    /**
     * @param Phone the Phone to set
     */
    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return Address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.Address = address;
    }
    }


  
        
        
        





