package Patient;

import Common.LoadApp;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.Id;
import static jdk.nashorn.internal.runtime.Debug.id;

public class PatientDAOImpl implements PatientDAO{

    @Override
            public void addPatient(Patient p) {
        String query = "insert into Profiles (username,email, password ,phone, address) values (?,?,?,?,?)";
        
        try {
            PreparedStatement ps = LoadApp.conn.prepareStatement(query);
            
            ps.setString(1, p.getUsername());
            ps.setString(2, p.getEmail());
            ps.setString(3, p.getPassword());
            ps.setString(4, p.getPhone());
            ps.setString(5, p.getAddress());
            
                    
            ps.execute();
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void deletePatient(int patientId) {
        String query = "delete from patients where Id = " + patientId;
        
        try {
            Statement stmt = LoadApp.conn.createStatement();
            
            stmt.executeUpdate(query);
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void updatePatient(Patient p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Fashion s.
    }

    @Override
    public Patient getPatient(int patientId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Fashion s.
    }

    @Override
    public List<Patient> getAllPatients() {
        
        List<Patient> list = new LinkedList<Patient>();
        
        String query = "select * from Profiles";
        
        try {
            Statement stmt = LoadApp.conn.createStatement();
            
            ResultSet rs =  stmt.executeQuery(query);
            
            while( rs.next() )
            {
                Patient p = new Patient();
                
                p.setId( rs.getInt("Id") );
                p.setUsername( rs.getString("Username") );
                p.setEmail( rs.getString("email") );
                p.setPhone( rs.getString("Phone") );
                p.setAddress(rs.getString("address") );
                
                list.add(p);
            }
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return list;
    }
}












